package com.example.smartspend

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
